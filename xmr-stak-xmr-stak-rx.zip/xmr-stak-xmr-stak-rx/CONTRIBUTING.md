## Contributing to XMR-Stak

:+1::tada: First off, thanks for taking the time to contribute! :tada::+1:

Please make sure your PR is against **dev** branch. Merging PRs directly into master branch would interfere with our workflow.


