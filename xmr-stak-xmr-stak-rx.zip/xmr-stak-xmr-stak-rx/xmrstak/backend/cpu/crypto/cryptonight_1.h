#pragma once

void* getRandomXDataset();

uint64_t getRandomXDatasetSize();
